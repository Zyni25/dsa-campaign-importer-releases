const MODULE_ID = "dsa-campaign-importer";
const IMPORT_BUTTON_ID = "dsa-campaign-importer-button";

Hooks.once("init", () => {
  console.log(`${MODULE_ID} | Initialisiert`);
});

Hooks.on("renderJournalDirectory", (_app, html) => {
  if (!game.user?.isGM) return;

  const root = html instanceof HTMLElement ? html : html?.[0];
  if (!root || root.querySelector(`#${IMPORT_BUTTON_ID}`)) return;

  const header = root.querySelector(".directory-header .header-actions")
    ?? root.querySelector(".directory-header");
  if (!header) return;

  const button = document.createElement("button");
  button.id = IMPORT_BUTTON_ID;
  button.type = "button";
  button.className = "dsa-campaign-importer-button";
  button.innerHTML = '<i class="fas fa-file-import"></i> DSA-Import';
  button.title = "DSA-Kampagneninhalte aus einer JSON-Datei importieren";
  button.addEventListener("click", selectAndImportFile);
  header.append(button);
});

async function selectAndImportFile() {
  const input = document.createElement("input");
  input.type = "file";
  input.accept = ".json,application/json";
  input.addEventListener("change", async () => {
    const file = input.files?.[0];
    if (!file) return;

    try {
      const payload = JSON.parse(await file.text());
      const summary = await importCampaign(payload);
      ui.notifications.info(
        `DSA-Import abgeschlossen: ${summary.created} erstellt, ${summary.skipped} übersprungen.`
      );
    } catch (error) {
      console.error(`${MODULE_ID} | Import fehlgeschlagen`, error);
      ui.notifications.error(`DSA-Import fehlgeschlagen: ${error.message}`);
    }
  }, { once: true });
  input.click();
}

async function importCampaign(payload) {
  validatePayload(payload);

  const basePath = normalizePath(payload.folderPath ?? [payload.folderName ?? "DSA-Import"]);
  const summary = { created: 0, skipped: 0 };

  for (const journal of payload.journals) {
    const path = normalizePath(journal.folderPath ?? basePath);
    const folder = await ensureFolderPath(path);

    const duplicate = game.journal.find(entry =>
      entry.name === journal.name && entry.folder?.id === folder.id
    );
    if (duplicate) {
      summary.skipped += 1;
      continue;
    }

    const content = buildJournalHtml(journal);
    await JournalEntry.create({
      name: journal.name,
      folder: folder.id,
      ownership: { default: CONST.DOCUMENT_OWNERSHIP_LEVELS.NONE },
      flags: {
        [MODULE_ID]: {
          importedAt: new Date().toISOString(),
          source: journal.source ?? null,
          sourcePage: journal.sourcePage ?? null,
          tags: Array.isArray(journal.tags) ? journal.tags : []
        }
      },
      pages: [{
        name: journal.pageName ?? journal.name,
        type: "text",
        text: {
          content,
          format: CONST.JOURNAL_ENTRY_PAGE_FORMATS.HTML
        },
        ownership: { default: CONST.DOCUMENT_OWNERSHIP_LEVELS.NONE }
      }]
    });
    summary.created += 1;
  }

  return summary;
}

function validatePayload(payload) {
  if (!payload || typeof payload !== "object") {
    throw new Error("Die JSON-Datei enthält kein gültiges Objekt.");
  }
  if (!Array.isArray(payload.journals) || payload.journals.length === 0) {
    throw new Error("Das Feld 'journals' fehlt oder ist leer.");
  }
  for (const [index, journal] of payload.journals.entries()) {
    if (!journal || typeof journal.name !== "string" || !journal.name.trim()) {
      throw new Error(`Journal ${index + 1} hat keinen gültigen Namen.`);
    }
    if (journal.contentHtml == null && journal.content == null) {
      throw new Error(`Journal '${journal.name}' enthält keinen Text.`);
    }
  }
}

function normalizePath(value) {
  const parts = Array.isArray(value) ? value : [value];
  const clean = parts.map(part => String(part).trim()).filter(Boolean);
  if (!clean.length) throw new Error("Der Zielordner ist leer.");
  return clean;
}

async function ensureFolderPath(parts) {
  let parent = null;
  let current = null;

  for (const name of parts) {
    current = game.folders.find(folder =>
      folder.type === "JournalEntry"
      && folder.name === name
      && (folder.folder?.id ?? null) === (parent?.id ?? null)
    );

    if (!current) {
      current = await Folder.create({
        name,
        type: "JournalEntry",
        folder: parent?.id ?? null,
        sorting: "a"
      });
    }
    parent = current;
  }

  return current;
}

function buildJournalHtml(journal) {
  const body = journal.contentHtml != null
    ? String(journal.contentHtml)
    : `<p>${escapeText(String(journal.content)).replaceAll("\n", "</p><p>")}</p>`;

  const sourceParts = [];
  if (journal.source) sourceParts.push(`<strong>Quelle:</strong> ${escapeText(String(journal.source))}`);
  if (journal.sourcePage) sourceParts.push(`<strong>Seite:</strong> ${escapeText(String(journal.sourcePage))}`);
  const sourceBlock = sourceParts.length
    ? `<hr><p class="dsa-campaign-importer-source">${sourceParts.join(" · ")}</p>`
    : "";

  return `${body}${sourceBlock}`;
}

function escapeText(value) {
  const element = document.createElement("div");
  element.textContent = value;
  return element.innerHTML;
}

export { importCampaign };
