# DSA Campaign Importer

Version 0.1.0 für Foundry Virtual Tabletop 14 (geprüfte Zielversion 14.363) und den Einsatz mit DSA5 8.1.4.

## Funktion

Das Modul ergänzt im Journal-Verzeichnis für Spielleiter die Schaltfläche **DSA-Import**. Eine ausgewählte JSON-Datei wird in Journalordner und Journaleinträge umgewandelt.

Sicherheitsverhalten:

- Nur Benutzer mit Spielleiterrechten sehen die Importschaltfläche.
- Bestehende gleichnamige Journale im selben Ordner werden übersprungen.
- Importierte Journale sind standardmäßig für Spieler unsichtbar.
- Das Modul löscht und überschreibt keine vorhandenen Dokumente.
- Bilder oder externe URLs werden in Version 0.1.0 nicht automatisch übertragen.

## Installation bei The Forge

Das ZIP enthält den vollständigen Modulordner. Lade es über die von deinem Forge-Tarif angebotene Funktion für benutzerdefinierte Module hoch. Falls deine Oberfläche nur Manifest-URLs akzeptiert, muss dieses Paket zunächst in einem öffentlich erreichbaren Git-Release abgelegt werden; die vorliegende Version enthält bewusst keine erfundene Downloadadresse.

Danach:

1. Welt stoppen beziehungsweise zum Einrichtungsbildschirm zurückkehren.
2. Modul installieren und die Welt starten.
3. Unter **Module verwalten** den **DSA Campaign Importer** aktivieren.
4. Als Spielleiter das Journal-Verzeichnis öffnen.
5. **DSA-Import** wählen und zuerst `examples/maraskan-beispiel.json` importieren.
6. Prüfen, ob `DSA-Quellarchiv/Maraskan` und der Beispielartikel angelegt wurden.

Vor dem ersten Einsatz in einer wichtigen Welt empfiehlt sich ein Forge-Backup.

## JSON-Format

```json
{
  "schemaVersion": 1,
  "folderPath": ["DSA-Quellarchiv", "Maraskan"],
  "journals": [
    {
      "name": "Artikelname",
      "pageName": "Übersicht",
      "contentHtml": "<h1>Titel</h1><p>Text</p>",
      "source": "Publikation",
      "sourcePage": "42–44",
      "tags": ["Maraskan"]
    }
  ]
}
```

Alternativ zu `contentHtml` kann `content` mit reinem Text verwendet werden. Ein Journal kann seinen Zielordner mit einem eigenen `folderPath` überschreiben.

## Geplante Erweiterungen

- Import mehrseitiger Journale
- Aktualisieren bereits importierter Einträge nach ausdrücklicher Bestätigung
- Würfeltabellen
- DSA5-Akteure
- Szenen und Bildzuordnung
